<!-- ###############################    Footer    ########################### -->
<footer>
    <p>&copy;2020 Cole Frost and Kiwan Lee</p>
</footer>