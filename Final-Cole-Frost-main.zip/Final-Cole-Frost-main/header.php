<!-- ##############################   Page Header   ############################# -->
<header class="header">
    <section>
        <article>
            <h2> Find your next adventure  </h2>
            <a href="index.php" class="btn btn-link">Home</a>
            <a href="showcase.php?county=Chittenden" class="btn btn-link">Showcase</a>
        </article>
    </section>
</header>
